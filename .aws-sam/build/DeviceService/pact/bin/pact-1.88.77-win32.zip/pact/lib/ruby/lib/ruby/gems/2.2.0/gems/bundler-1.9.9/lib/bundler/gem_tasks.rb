require 'bundler/gem_helper'
Bundler::GemHelper.install_tasks
